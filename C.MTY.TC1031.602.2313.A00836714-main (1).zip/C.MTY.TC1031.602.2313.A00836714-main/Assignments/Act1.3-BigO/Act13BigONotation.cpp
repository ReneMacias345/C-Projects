#include <iostream>
#include <vector>
using namespace std;


int sumImpares(int v[],int n){
    int sum=0;
    for (int i=0;i<=n;i++){
        if (v[i]%2!=0){
            sum=sum+v[i];
        }
    }
    return sum;
}

// es de orden o(n)

int sumImparesRecur(int v[],int n){
    if (n+1>0){
        if (v[n]%2!=0){
            return v[n]+sumImparesRecur(v,n-1);
        }else{
            return sumImparesRecur(v,n-1);
        }
    }else{
        return 0;
    }
}

//es de orden o(n)

int main()
{
    int v1[]={2,3,4,6,7,3,7,5};
    int n1= sizeof(v1)/sizeof(v1[0]);
    int sumaimp=sumImpares(v1,n1);
    cout<<sumaimp<<endl;
    int sumaimpRecur=sumImparesRecur(v1,n1);
    cout<<sumaimpRecur<<endl;
    return 0;
}
