#include <iostream>
using namespace std;

int sumIterative(int n){
   int sum=0;
   for (int i=1;i<=n;i++){
    sum=sum+i;
   }
    return sum;
}

int sumRecursive(int n){
  if (n > 0) {
        return n + sumRecursive(n-1);
    } else {
        return 1;
    }
}

int sumFormula(int n){
    return n*(n+1)/2;
}

int fibonacciIterative(int n){
   int f1=1; int f2=0; int f3=0;
   for (int i=1;i<=n;i++){
    f3=f1+f2;
    f1=f2;
    f2=f3;
    }
    return f3;
}

int fibonacciRecursive(int n){
  if (n == 1||n==2) {
        return 1;
    } else {
        return fibonacciRecursive(n-1)+fibonacciRecursive(n-2);
    }
}

int bacteriasIterative(int n){
   int bacteria=1;
   float rate=1.44;
   for (int i=1;i<=n;i++){
    bacteria=bacteria+(bacteria*rate); 
   }
    return bacteria;
}   

int bacteriasRecursive(int n){
   if (n > 0) {
    int bacterias=bacteriasRecursive(n-1);
    float born= bacterias*1.44;
    return bacterias+born;
    } else {
        return 1;
    }
}

float investmentIterative(float balance, int meses){
    float intereeserate=18.75;
    float newbalance = balance;
    for ( int i=1;i <=meses;i++){
        newbalance= newbalance*(1+ intereeserate/100);
    }
    return newbalance;
}

float investmentRecursive(float balance, int meses){
   if (meses > 0) {
    return investmentRecursive(balance,meses-1)*(1+18.75/100);
    } else {
        return balance;
    }
}

int powIterative(int n,int y){
   int num=n;
   for (int i=2;i<=y;i++){
    num=num*n;
   }
    return num;
}

int powRecursive(int n,int y){
  if (y > 0) {
        return n * powRecursive(n,y-1);
    } else {
        return 1;
    }
}



int main()
{
    int sum1=sumIterative(5);
    cout<< "la suma de 1 al 5 es: "<<sum1<<endl; 

    int sum2=sumIterative(5);
    cout<< "la suma de 1 al 5 es: "<<sum2<<endl; 

    int sum3=sumIterative(5);
    cout<< "la suma de 1 al 5 es: "<<sum3<<endl; 

    int fibonacci1=fibonacciIterative(6);
    cout<< "el número fibonacci de 6: "<<fibonacci1<<endl; 

    int fibonacci2=fibonacciRecursive(6);
    cout<< "el número fibonacci de 6: "<<fibonacci2<<endl; 

    int bacteria1=bacteriasIterative(10);
    cout<< "el número de bacterias en el dia 10 es de: "<<bacteria1<<endl;

    int bacteria2=bacteriasRecursive(10);
    cout<< "el número de bacterias en el dia 10 es de: "<<bacteria2<<endl;

    float montofinal1=investmentIterative(1000,5);
    cout<< "el monto final es de : "<<montofinal1<<endl;

    float montofinal2=investmentRecursive(1000,5);
    cout<< "el monto final es de : "<<montofinal2<<endl;

    int potenciado1=powIterative(5,4);
    cout<<"el numero 5 elevado a la potencia 4 es: "<<potenciado1<<endl;

    int potenciado2=powRecursive(5,4);
    cout<<"el numero 5 elevado a la potencia 4 es: "<<potenciado2<<endl;


    return 0;
}
