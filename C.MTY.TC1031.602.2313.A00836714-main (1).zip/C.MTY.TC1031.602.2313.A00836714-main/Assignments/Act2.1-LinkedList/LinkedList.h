#ifndef LinkedList_h
#define LinkedList_h

#include "Node.h"

template<class T>
class LinkedList {
private:
    Node<T>* head;
    int size;
public:
    LinkedList();
    void addFirst(T data);
    void addLast(T data);
    void print();
    int getSize();
    bool isEmpty();
    void insert(int index,T data);
    void getData(int index);
    int findData(T data);
    void deleteData(T data);
    void updateData(T data1, T data2);
    void updateAt(int index, T data);
    bool deleteAt(int pos);
    T& operator[](int pos);
    void operator=(LinkedList<T> list);
    void clear();
};

template<class T>
LinkedList<T>::LinkedList() {
    head = nullptr;
    size = 0;
}

template<class T>
int LinkedList<T>::getSize() {
    return size;
}

template<class T>
void LinkedList<T>::addFirst(T data) {
    // Apuntamos head a un nuevo nodo que apunte a head
    head = new Node<T>(data, head);
    //Incrementamos el valor de size en 1
    size++;
}

template<class T>
void LinkedList<T>::print() {
    // Definimos un apuntador de tipo de nodo igual a head;
    Node<T>* aux = head;
    while (aux != nullptr) {
        // Imprimimos el valor del nodo
        cout << aux->data;
        if (aux->next != nullptr) {
            cout << " -> ";
        }
        // Asignamos a aux el valor de next de aux
        aux = aux->next;
    }
    // Imprimimos un salto de linea
    cout << endl;
}

template<class T>
void LinkedList<T>::addLast(T data) {
    // Validamos si la lista esta vacía
    if (isEmpty()) {
        head = new Node<T>(data);
    } else {
        // Definimos un apuntador auxiliar igual a head para recorrer la lista
        Node<T>* aux = head;
        // Vamos recorrer la lista hasta llegar al último nodo
        while (aux->next != nullptr) {
            // recorremos aux
            aux = aux->next;
        }
        // Creamos un nodo nuevo
        aux->next = new Node<T>(data);
    }
    // Incrementamos el tamaño de la lista
    size++;
}

template<class T>
bool LinkedList<T>::isEmpty() {
    return size == 0;
}

template<class T>
void LinkedList<T>::insert(int index, T data) {
    // Validamos que el índece exista en la lista
    if (index >= 0 && index < size) {
        // Definimos un índex auxiliar igual a 0
        int auxIndex = 0;
        // DEfinimos un apuntador auxiliar igual a head
        Node<T>* aux = head;
        // Recorremos la lista
        while (auxIndex != index) {
            // Recorremos aux
            aux = aux->next;
            // Incrmenatmos el valor de índice auxliar
            auxIndex++;
        } 
        // Insertamos el valor
        aux->next = new Node<T>(data, aux->next);
        // Incrementamos el valor de size
        size++;
    } else {
        throw out_of_range("El índice no se encuentra en la lista");
    }
}

template<class T>
void LinkedList<T>::getData(int index) {
    // Validamos que el índece exista en la lista
    if (index >= 0 && index < size) {
        // Definimos un índex auxiliar igual a 0
        int auxIndex = 0;
        // DEfinimos un apuntador auxiliar igual a head
        Node<T>* aux = head;
        // Recorremos la lista
        while (auxIndex != index) {
            // Recorremos aux
            aux = aux->next;
            // Incrmenatmos el valor de índice auxliar
            auxIndex++;
        } 
        // Imprimimos el valor
        cout << aux->data << endl;
    } else {
        throw out_of_range("El índice no se encuentra en la lista");
    }
}

template<class T>
int LinkedList<T>::findData(T data){
    Node<T>* aux = head;
    int auxindex = 0;
    while(aux!=nullptr){
        if(data==aux->data){
            return auxindex;
        }else{
            aux = aux->next;
            auxindex++;
        }
    }
    return -1;
}   

template<class T>
void LinkedList<T>::deleteData(T data){
    Node<T>* aux = head;
    Node<T>* aux2 = head;
    int auxindex = 0;
    while(aux!=nullptr){
        if(data==aux->data){
            aux2->next = aux->next;
            delete aux;
            size--;
            break;
        }else{
            aux2 = aux;
            aux = aux->next;
            auxindex++;
        }
    }
}

template<class T>  
void LinkedList<T>::updateData(T data1, T data2){
    Node<T>* aux = head;
    int auxindex = 0;
    while(aux!=nullptr){
        if(data1==aux->data){
            aux->data = data2;
            break;
        }else{
            aux = aux->next;
            auxindex++;
        }
    }
}

template<class T>
void LinkedList<T>::updateAt(int index, T data){
    // Validamos que el índece exista en la lista
    if (index >= 0 && index < size) {
        // Definimos un índex auxiliar igual a 0
        int auxIndex = 0;
        // DEfinimos un apuntador auxiliar igual a head
        Node<T>* aux = head;
        // Recorremos la lista
        while (auxIndex != index) {
            // Recorremos aux
            aux = aux->next;
            // Incrmenatmos el valor de índice auxliar
            auxIndex++;
        } 
        // Imprimimos el valor
        aux->data = data;
    } else {
        throw out_of_range("El índice no se encuentra en la lista");
    }
}

template<class T>
bool LinkedList<T>::deleteAt(int pos){
    if (pos>=0 && pos<size){
        Node<T>* aux = head;
        if (pos == 0){
            head = aux->next;
            delete aux;
            size--;
            return true;
        }else{
            for (int i=0; i<pos-1; i++){
                aux = aux->next;
            }
            Node<T>* aux2 = aux->next;
            aux->next = aux2->next;
            delete aux2;
            size--;
            return true;
        }
    }else{
        return false;
    }
}

template <class T>
T& LinkedList<T>::operator[](int index) {
    if (index >= 0 && index < size) {
        Node<T>* aux = head;
        int auxIndex = 0;
        while (auxIndex < index) {
            aux = aux->next;
            auxIndex++;
        }
        return aux->data;
    } else {
        throw out_of_range("Índice inválido");
    }
}

template <class T>
void LinkedList<T>::operator=(LinkedList<T> list) {
    clear();
    Node<T>* aux = list.head;
    while (aux != nullptr) {
        addLast(aux->data);
        aux = aux->next;
    }
}

template <class T>
void LinkedList<T>::clear(){
    Node<T>* aux = head;
    while (aux != nullptr) {
        head = aux->next;
        delete aux;
        aux = head;
    }
    size = 0;
}








#endif
