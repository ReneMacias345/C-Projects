#include <iostream>
using namespace std;
#include "LinkedList.h"

int main() {

    LinkedList<string> list;
    //list.addLast("Cuchara");
    list.addFirst("Olla");
    list.addFirst("Estufa");
    list.addFirst("Jarra");
    list.addFirst("Plato");
    list.print();
    list.addLast("Cuchara");
    cout << "Tamaño de la lista: " << list.getSize() << endl;
    list.print();
    list.insert(1, "Tenedor");
    list.print();
    cout << "Tamaño de la lista: " << list.getSize() << endl;
    list.getData(1);
    cout<<list.findData("a")<<endl;
    cout<<list.findData("Cuchara")<<endl;
    list.deleteData("Cuchara");
    list.print();
    list.updateData("Tenedor","Vaso");
    list.print();
    list.updateAt(0,"Licuadora");
    list.print();
    list.deleteAt(1);
    list.print();

    return 0;
}