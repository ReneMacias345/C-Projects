#include <iostream>
using namespace std;

int sumint(int a, int b){
    return a+b;
}

double sumdouble(double a, double b){
        return a+b;
}

string sumstring(string a, string b){
    return a+b;
}

template <class T>
T sum(T a, T b){
    return a+b;
}

int main(){
int a, b,c;
a=5;
b=10;
c=sumint(a,b);
cout<<a<<" + "<<b<<" = "<<c<<endl;

double x,y,z;
x=1.5;
y=2.5;
z=sumdouble(x,y);
cout<<z<<endl;

string s1,s2,s3;
s1="2";
s2="3";
s3=sumstring(s1,s2);
cout<<s3<<endl;

c=sum(a,b);
z=sum(x,y);
s3=sum(s1,s2);

cout<<c<<endl;
cout<<z<<endl;
cout<<s3<<endl;

}