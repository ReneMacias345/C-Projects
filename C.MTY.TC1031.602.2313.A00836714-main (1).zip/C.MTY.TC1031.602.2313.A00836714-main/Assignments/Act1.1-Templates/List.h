#ifndef List_h
#define List_h

template <class T>
class List {
private:
    vector<T> list;
    int size;
public:
    List();
    void insert(T data);
    void removeLast();
    T getdata(int index);
    int getSize();
    T getMax();
    void print();
};

// Hacer constructor por default
template <class T>
List<T>::List() {
    // inicializo el tamaño de la lista en 0
    size = 0;
}

// Hacer método de insert
template <class T>
void List<T>::insert(T data) {
    // insertar el dato al final de la lista
    list.push_back(data);
    // incrementamos el tamaño de la lista
    size++;
}

// Remueve el último elemento de la lista
template <class T>
void List<T>::removeLast() {
    // Validamos que la lista no este vacia
    if (size > 0) {
        // Desplegamos el último elemento de la lista
        cout << "El elemento a eliminar es: " << list[size-1] << endl;
        // removemos el último elemento de la lista
        list.pop_back();
        // decrementamos el tamaño de la lista
        size--;
    } else {
        cout << "La Lista está vacía" << endl;
    }
}

// Obetener el dato de un elemento de la lista
template <class T>
T List<T>::getdata(int index) {
    // Validamos que exista el dato a obtener
    if (index >= 0 && index < size) {
        // retornamos el dato
        return list[index];
    } else {
        // retornamos un dato nulo
        throw out_of_range("Posición inválida");
    }
}

// Obtener el tamaño de la lista
template <class T>
int List<T>::getSize() {
    cout<<"el tamano del vector es de: "<<size<<" datos"<<endl;
    return 0;
}

// Obtener el dato máximo de la lista
template <class T>
T List<T>::getMax() {
    // Validamos que la lista no este vacia
    if (size > 0) {
        // Inicializamos el dato máximo con el primer elemento de la lista
        T max = list[0];
        // Recorremos la lista para encontrar el dato máximo
        for (int i=1; i<size; i++) {
            // Validamos si el dato actual es mayor al dato máximo
            if (list[i] > max) {
                // Actualizamos el dato máximo
                max = list[i];
            }
        }
        // Retornamos el dato máximo
        cout<<"el valor maximo es de: "<<max<<endl;
        return 0;
    } else {
        // Retornamos un dato nulo
        throw out_of_range("La lista está vacía");
    }
}
// Hacer método de print
template <class T>
void List<T>::print() {
    // Recorrer la lista par imprimir cada uno de sus elementos
    for (int i=0; i<size; i++) {
        // imprimimos el elemento
        cout << "[" << i << "] - " << list[i] << " valor "<< i+1 << endl;
    }
    
}


#endif