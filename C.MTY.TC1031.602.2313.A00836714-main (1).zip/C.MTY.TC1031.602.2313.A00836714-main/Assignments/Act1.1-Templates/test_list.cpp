#include <iostream>
#include <vector>
using namespace std;

#include "List.h"

int main()
{
    List<int> list;

    // insertar datos
    list.insert(5);
    list.insert(10);
    list.insert(15);
    list.insert(20);
    list.insert(25);

    // imprimimos la lista
    list.print();

    // tamano de la lista
    list.getSize();

    // Dato con mayor valor de la lista
    list.getMax();

    //Eliminar valores de la lista
    list.removeLast();
    list.removeLast();
    list.removeLast();

    //Prueba despues de eliminar datos

    list.print();

    list.getMax();

    list.getSize();

    //obtner el valor de una posicion en especifico

    cout<<"El valor de la posicion 0 es: "<<list.getdata(0)<<endl;
    
    //obtener un dato ineccistente

    cout<<"El valor de la posicion 3 es: "<<list.getdata(3)<<endl;

    return 0;
}
