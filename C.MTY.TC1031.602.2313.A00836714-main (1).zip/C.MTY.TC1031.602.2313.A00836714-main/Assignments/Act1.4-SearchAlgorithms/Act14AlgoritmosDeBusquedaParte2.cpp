#include <iostream>
#include <vector>
#include <string>
using namespace std;


string caracterunicoSecuencial(string str){
    int n=str.length();
    int contador=0;
    for(int i=0;i<=n;i+=2){
        if (str[i]!=str[i+1]){
            contador++;
            cout<<str[i]<<" "<<contador<<endl;
            break;
        }else{
            contador++;
        }
    }
    return "";
}

string caracterunicoBinario(string str){

    int left=0;
    int right=str.size()-1;
    int contador=0;

    while(left<=right){

        int mid=left + (right-left)/2;

        if (str[mid]!=str[mid+1] && str[mid]!=str[mid-1]){
            contador++;
            cout<<str[mid]<<" "<<contador<<endl;
            return "";

        }else{

            if(str[mid]==str[mid+1]){
                contador++;
                right=mid-1;

            }if(str[mid]==str[mid-1]){
                contador++;
                left=mid+1;
            }
        }
    }
    return "";
}


int main(){
    string str1="AACCZZTTVXX";
    string str2="AAB";
    string str3="CCAAXWWTT";
    string str4="XXYYZZAAC";
    caracterunicoSecuencial(str1), caracterunicoBinario(str1);
    caracterunicoSecuencial(str2);
    caracterunicoBinario(str2);
    caracterunicoSecuencial(str3);
    caracterunicoBinario(str3);
    caracterunicoSecuencial(str4);
    caracterunicoBinario(str4);
    return 0;
}
