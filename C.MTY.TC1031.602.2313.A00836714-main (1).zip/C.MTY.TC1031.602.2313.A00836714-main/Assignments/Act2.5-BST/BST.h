#ifndef BST_h
#define BST_h

#include "TNode.h"

template <class T>
class BST {
private:
    TNode<T>* root;
    void printTree(TNode<T>* aux, int level);
    void preorder(TNode<T>* aux);
    void inorder(TNode<T>* aux);
    void postorder(TNode<T>* aux);
    void levelByLevel(TNode<T>* aux);
public:
    BST();
    void insert(T data);
    bool find(T data);
    void print();
    bool isEmpty();
    bool remove(T data);
    void visit(int tipoOrden);
    void height();
    void ancestors(T data);
    int whatLevelamI(T data);

};

template <class T>
BST<T>::BST() {
    root = nullptr;
}

template <class T>
void BST<T>::insert(T data) {
    // Validamos si el arbol esta vacío
    if (isEmpty()) {
        // El árbol está vacío
        // root va a ser igual a un nuevo nodo con el valor de data
        root = new TNode<T>(data);
    } else {
        // El arbol no está vacío
        // Creamos un apuntador auxiliar apuntado a roor
        TNode<T>* aux = root;
        // Iteramos el árbol hasta poder insertar el valor nuevo (aux != nullptr)
        while (aux != nullptr) {
            // Comparamos si data es menor a aux->data
            if (data < aux->data) {
                // si es menor
                // Validamos si el apuntador del lado izquierdo de aux es nulo
                if (aux->left == nullptr) {
                    // si es nulo
                    // aux->left va a ser igual a nuevo nodo con el valor de data
                    aux->left = new TNode<T>(data);
                    // nos salimos de la función
                    return;
                } else {
                    // no es nulo
                    // Recorremos aux hacia aux->left
                    aux = aux->left;
                }
            } else {
                // es mayor o igual
                // Validamos si el apuntador del lado derecho de aux es nulo
                if (aux->right == nullptr) {
                    // si es nulo
                    // aux->right va a ser igual a nuevo nodo con el valor de data
                    aux->right = new TNode<T>(data);
                    // nos salimos de la función
                    return;
                } else {
                    // no es nulo
                    // Recorremos aux hacia aux->right
                    aux = aux->right;
                }
            }
        }
    }
}


template<class T>
void BST<T>::printTree(TNode<T>* aux, int level) {
    if (aux != NULL) {
        printTree(aux->right,level+1);
        for (int i=0;i<level;i++) {
            cout << "  ";
        }
        cout << aux->data << endl;
        printTree(aux->left,level+1);
    }
}

template<class T>
void BST<T>::print() {
    if (!isEmpty()) {
        int level = 0;
        cout << endl;
        printTree(root, level);
        cout << endl;
    } else {
        cout << endl << "The BST is empty" << endl << endl;
    }
} 

template <class T>
bool BST<T>::isEmpty() {
    return root == nullptr;
}

template <class T>
bool BST<T>::remove(T data){
    if (isEmpty()) {
        return false;
    } else {
        TNode<T>* aux = root;
        TNode<T>* father = nullptr;
        while (aux != nullptr) {
            if (data == aux->data) {
                break;
            }
            father = aux;
            if (data > aux->data) {
                aux = aux->right;
            } else {
                aux = aux->left;
            }
        }
        if (aux == nullptr) {
            return false;
        }
        if (aux->left == nullptr && aux->right == nullptr) {
            if (father != nullptr) {
                if (father->left == aux) {
                    father->left = nullptr;
                } else {
                    father->right = nullptr;
                }
            } else {
                root = nullptr;
            }
            delete aux;
        } else if (aux->left != nullptr && aux->right == nullptr) {
            if (father != nullptr) {
                if (father->left == aux) {
                    father->left = aux->left;
                } else {
                    father->right = aux->left;
                }
            } else {
                root = aux->left;
            }
            delete aux;
        } else if (aux->left == nullptr && aux->right != nullptr) {
            if (father != nullptr) {
                if (father->left == aux) {
                    father->left = aux->right;
                } else {
                    father->right = aux->right;
                }
            } else {
                root = aux->right;
            }
            delete aux;
        } else {
            TNode<T>* fatherAux = aux;
            TNode<T>* aux2 = aux->left;
            while (aux2->right != nullptr) {
                fatherAux = aux2;
                aux2 = aux2->right;
            }
            aux->data = aux2->data;
            if (fatherAux->left == aux2) {
                fatherAux->left = aux2->left;
            } else {
                fatherAux->right = aux2->left;
            }
            delete aux2;
        }
        return true;
    }
}
template <class T>
bool BST<T>::find(T data) {
    // Creamos un apuntador auxiliar igual a root
    TNode<T>* aux = root;
    // Recorremos el árbol para buscar data
    while (aux != nullptr) {
        // Validamos si data a igual aux->data
        if (aux->data == data) {
            return true;
        } else {
            data < aux->data ? aux = aux->left : aux = aux->right;
        }
    }
    // No lo encontramos
    return false;
}

template <class T>
void BST<T>::preorder(TNode<T>* aux) {
    if (aux != nullptr) {
        cout << aux->data << " ";
        preorder(aux->left);
        preorder(aux->right);
    }
}

template <class T>
void BST<T>::inorder(TNode<T>* aux) {
    if (aux != nullptr) {
        inorder(aux->left);
        cout << aux->data << " ";
        inorder(aux->right);
    }
}

template <class T>
void BST<T>::postorder(TNode<T>* aux) {
    if (aux != nullptr) {
        postorder(aux->left);
        postorder(aux->right);
        cout << aux->data << " ";
    }
}

template <class T>
void BST<T>::levelByLevel(TNode<T>* aux) {
    if (aux != nullptr) {
        queue<TNode<T>*> q;
        q.push(aux);
        while (!q.empty()) {
            TNode<T>* current = q.front();
            q.pop();
            cout << current->data << " ";
            if (current->left != nullptr) {
                q.push(current->left);
            }
            if (current->right != nullptr) {
                q.push(current->right);
            }
        }
    }
}

template <class T>
void BST<T>::visit(int tipoOrden) {
    if (isEmpty()) {
        cout << "El arbol esta vacio" << endl;
        return;
    }

    switch (tipoOrden) {
        case 1:
            preorder(root);
            break;
        case 2:
            inorder(root);
            break;
        case 3:
            postorder(root);
            break;
        case 4:
            levelByLevel(root);
            break;
        default:
            cout << "Invalid option" << endl;
            break;
    }
}

template <class T>
void BST<T>::height() {
    if (isEmpty()) {
        cout << "El arbol esta vacio" << endl;
    } else {
        queue<TNode<T>*> q;
        q.push(root);
        int height = 0;
        while (true) {
            int nodeCount = q.size();
            if (nodeCount == 0) {
                cout << "La altura del arbol es: " << height << endl;
                return;
            }
            height++;
            while (nodeCount > 0) {
                TNode<T>* node = q.front();
                q.pop();
                if (node->left != nullptr) {
                    q.push(node->left);
                }
                if (node->right != nullptr) {
                    q.push(node->right);
                }
                nodeCount--;
            }
        }
    }
}

template <class T>
void BST<T>::ancestors(T data) {
    if (isEmpty()) {
        cout << "El arbol esta vacio" << endl;
    } else {
        if(!find(data)){
            cout<<"No encontrado"<<endl;
            return;
        }
        TNode<T>* aux = root;
        while (aux != nullptr) {
            if (aux->data == data) {
                data;
                return;
            } else if (data < aux->data) {
                cout << aux->data << " ";
                aux = aux->left;
            } else {
                cout << aux->data << " ";
                aux = aux->right;
            }
        }
        cout << endl;
    }
}

template <class T>
int BST<T>::whatLevelamI(T data) {
if (isEmpty()) {
        return -1;
    }

    int level = 1;
    TNode<T>* aux = root;

    while (aux != nullptr) {
        if (aux->data == data) {
            return level;
        } else if (data < aux->data) {
            aux = aux->left;
        } else {
            aux = aux->right;
        }
        level++;
    }
    return -1;
}

#endif /* BST_h */