#include <iostream>
using namespace std;

#include "BST.h"

int main() {

    BST<int> bst;

    bst.insert(20);
    bst.insert(30);
    bst.insert(10);
    bst.insert(5);
    bst.insert(35);
    bst.insert(15);
    bst.insert(25);     
    bst.print();
    cout<<bst.find(10);
    bst.remove(35);
    bst.print();
    bst.remove(20);
    bst.print();
    bst.height();
    bst.ancestors(15);
    bst.ancestors(25);
    bst.visit(1);
    bst.visit(2);
    bst.whatLevelamI(15);


    return 0;
}