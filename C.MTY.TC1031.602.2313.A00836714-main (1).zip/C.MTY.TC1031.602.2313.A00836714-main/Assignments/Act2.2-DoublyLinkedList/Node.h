#pragma once

template<class T>
struct Node
{
    T data;
    Node<T>* prev;
    Node<T>* next;
    Node();
    Node(T data);
    Node(T data, Node<T>* prev, Node<T>* next);
};

template<class T>
Node<T>::Node()
{
    prev = nullptr;
    next = nullptr;
}

template<class T>
Node<T>::Node(T data)
{
    this->data = data;
    this->prev = nullptr;
    this->next = nullptr;
}

template<class T>
Node<T>::Node(T data, Node<T>* prev, Node<T>* next)
{
    this->data = data;
    this->prev = prev;
    this->next = next;
}