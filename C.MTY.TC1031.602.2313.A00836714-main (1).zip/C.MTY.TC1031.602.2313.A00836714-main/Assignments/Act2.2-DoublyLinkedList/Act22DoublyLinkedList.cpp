#include <iostream>
using namespace std;
#include "DoublyLinkedList.h"
#include <string>

int main (){
    int tipodelista;
    int tipodedato;
    DoublyLinkedList<int> list1;
    DoublyLinkedList<char> list2;
    cout<<"Que tipo de lista desea crear? 1)Int 2)Char"<<endl;
    cin>>tipodelista;
    cout<<"Que tipo de dato desea utilizar? 1)aleatoreo 2)capturado"<<endl;
    cin>>tipodedato;

    if(tipodelista==1 && tipodedato==1){
      int quantity;
      cout<<"Cuantos datos desea ingresar?"<<endl;
      cin>>quantity;
      for (int i = 0; i < quantity; i++)
      {
        int num = rand() % 50 + 1;
        list1.addFirst(num);
      }
      list1.print();
    }

    if(tipodelista==1 && tipodedato==2){
      int cantidad;
      cout<<"Cuantos datos desea ingresar?"<<endl;
      cin>>cantidad;
      for(int i=0;i<cantidad;i++){
        int dato;
        cout<<"Ingrese el dato"<<endl;
        cin>>dato;
        list1.addFirst(dato);
      }
      list1.print();
    }

    if(tipodelista==2 && tipodedato==1){
      int quantity;
      cout<<"Cuantos datos desea ingresar?"<<endl;
      cin>>quantity;
      for (int i = 0; i < quantity; i++)
      {
        int num = 91;
        while (num >= 91 && num <= 96)
        {
          num = rand() % 58 + 65;
        }
        list2.addFirst(char(num));
      }
      list2.print();

    }

    if(tipodelista==2 && tipodedato==2){
      int cantidad;
      cout<<"Cuantos datos desea ingresar?"<<endl;
      cin>>cantidad;
      for(int i=0;i<cantidad;i++){
        char dato;
        cout<<"Ingrese el dato"<<endl;
        cin>>dato;
        list2.addFirst(dato);
      }
      list2.print();
    }
  
    int menu ;
    cout<<"Que desea hacer?"<<endl;
    cout<<"1)Agrega un elemento al principio de la lista"<<endl;
    cout<<"2)Agrega un elemento al final de la lista"<<endl;
    cout<<"3)Insertar un elemento a la derecha del índice dado"<<endl;
    cout<<"4)Borrar un elemento dado de la lista"<<endl;
    cout<<"5)Borrar un elemento en una posición de la lista"<<endl;
    cout<<"6)Obtener el elemento de una posición dada de la lista"<<endl;
    cout<<"7)Actualizar un elemento dado de la lista"<<endl;
    cout<<"8)Actualizar un elemento que se encuentra en una posición dada de la lista"<<endl;
    cout<<"9)Encuentra un elemento dado en la lista"<<endl;
    cout<<"10)Obtener el elemento de una posición de la lista. (Sobre cargo operador [ ])"<<endl;
    cout<<"11)Actualizar el elemento de una posición de la lista. (Sobre cargo operador [ ])"<<endl;
    cout<<"12)Iguala una lista con los datos de otra lista (Sobre carga operador =) (Duplica la lista)"<<endl;
    cout<<"13)Limpiar la lista"<<endl;
    cout<<"14)Ordena la lista"<<endl;
    cout<<"15)Duplica la lista"<<endl;
    cout<<"16)Remueve los elementos duplicados"<<endl;
    cin>>menu;

    if((tipodelista==1 && tipodedato==1)||(tipodelista==1 && tipodedato==2)){
        if(menu==1){
            int dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list1.addFirst(dato);
            list1.print();
        }
        if(menu==2){
            int dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list1.addLast(dato);
            list1.print();
        }
        if(menu==3){
            int dato;
            int indice;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            list1.insert(indice,dato);
            list1.print();
        }
        if(menu==4){
            int dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list1.deleteData(dato);
            list1.print();
        }
        if(menu==5){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            list1.deleteAt(indice);
            list1.print();
        }
        if(menu==6){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<list1.getData(indice)<<endl;
        }
        if(menu==7){
            int dato;
            int nuevodato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list1.updateData(dato,nuevodato);
            list1.print();
        }
        if(menu==8){
            int indice;
            int nuevodato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list1.updateAt(indice,nuevodato);
            list1.print();
        }
        if(menu==9){
            int dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<list1.findData(dato)<<endl;
            list1.print();
        }
        if(menu==10){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<list1[indice]<<endl;
            list1.print();
        }
        if(menu==11){
            int indice;
            int nuevodato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list1[indice]=nuevodato;
            list1.print();
        }
        if(menu==12){
            DoublyLinkedList<int> list3;
            list3=list1;
            list3.print();
        }
        if(menu==13){
            list1.clear();
            list1.print();
        }
        if(menu==14){
            list1.sort();
            list1.print();
        }
        if(menu==15){
            list1.duplicate();
            list1.print();
        }
        if(menu==16){
            list1.removeDuplicates();
            list1.print();
        }

    }

    if((tipodelista==2 && tipodedato==1)||(tipodelista==2 && tipodedato==2)){
        if(menu==1){
            char dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list2.addFirst(dato);
            list2.print();
        }
        if(menu==2){
            char dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list2.addLast(dato);
            list2.print();
        }
        if(menu==3){
            char dato;
            int indice;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            list2.insert(indice,dato);
            list2.print();
        }
        if(menu==4){
            char dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            list2.deleteData(dato);
            list2.print();
        }
        if(menu==5){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            list2.deleteAt(indice);
            list2.print();
        }
        if(menu==6){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<list2.getData(indice)<<endl;
        }
        if(menu==7){
            char dato;
            char nuevodato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list2.updateData(dato,nuevodato);
            list2.print();
        }
        if(menu==8){
            int indice;
            char nuevodato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list2.updateAt(indice,nuevodato);
            list2.print();
        }
        if(menu==9){
            char dato;
            cout<<"Ingrese el dato"<<endl;
            cin>>dato;
            cout<<list2.findData(dato)<<endl;
            list2.print();
        }
        if(menu==10){
            int indice;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<list2[indice]<<endl;
            list2.print();
        }
        if(menu==11){
            int indice;
            char nuevodato;
            cout<<"Ingrese el indice"<<endl;
            cin>>indice;
            cout<<"Ingrese el nuevo dato"<<endl;
            cin>>nuevodato;
            list2[indice]=nuevodato;
            list2.print();
        }
        if(menu==12){
            DoublyLinkedList<char> list3;
            list3=list2;
            list3.print();
        }
        if(menu==13){
            list2.clear();
            list2.print();
        }
        if(menu==14){
            list2.sort();
            list2.print();
        }
        if(menu==15){
            list2.duplicate();
            list2.print();
        }
        if(menu==16){
            list2.removeDuplicates();
            list2.print();
        }
    }
}