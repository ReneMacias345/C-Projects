#include <iostream>
#include <vector>
#include <string>
#include <chrono>
using namespace std;

void startTime(chrono::high_resolution_clock::time_point &begin)
{
  // start time
  begin = std::chrono::high_resolution_clock::now();
  
}

// Imprime el tiempo transcurrido desde el valor de start hasta el momento que se ejecuta la función
void getTime(chrono::high_resolution_clock::time_point begin, chrono::high_resolution_clock::time_point end) 
{
    end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);

    printf("Tiempo de ejecución: %.8f seconds.\n", elapsed.count() * 1e-9);
}


template<class T>
void swap(vector<T> &list, int a, int b) {
    if (list[a] != list[b]) {
        T aux = list[a];
        list[a] = list[b];
        list[b] = aux;
    }
}

template<class T>
void print(vector<T> list) {
    for (auto l : list) {
        cout << l << " ";
    }
    cout << endl;
}

void createListInt(vector<int> &list, int quantity)
{
  for (int i = 0; i < quantity; i++)
  {
    int num = rand() % 50 + 1;
    list.push_back(num);
  }
}

void createListChar(vector<char> &list, int quantity)
{
  for (int i = 0; i < quantity; i++)
  {
    int num = 91;
    while (num >= 91 && num <= 96)
    {
      num = rand() % 58 + 65;
    }
    list.push_back(char(num));
  }
}

void createListFloat(vector<float> &list, int quantity)
{
for (int i = 0; i < quantity; i++)
    {
        float num = static_cast<float>((rand() % 10001) / 100.0);
        list.push_back(num);
    }
}


template<class T>
void SwapSort(vector<T>list,int &compa, int &swaps){
    int comparaciones=compa;
    int intercambios=swaps;
    for (int i=0;i<list.size()-1;i++){
        for (int j=i+1;j<list.size();j++){
            comparaciones++;
            if (list[i]>=list[j]){
                intercambios++;
                swap(list,i,j);
            }
        }
    }
    print(list);
    cout<<"Comparaciones "<<comparaciones<<" intercambios: "<<intercambios<< endl; 
}

template<class T>
void BubbleSort(vector<T>list,int &compa, int &swaps){
    int comparaciones=compa;
    int intercambios=swaps;
    int iter=0;
    bool control=true;
    while (iter<list.size()-1 && control){
        control=false;
        for (int i=1;i<list.size()-iter;i++){
            comparaciones++;
            if (list[i-1]>=list[i]){
                intercambios++;
                swap(list,i-1,i);
                control=true;
            }
        }
        iter++;
    }
    print(list);
    cout<<"Comparaciones "<<comparaciones<<" intercambios: "<<intercambios<< endl; 
}

template<class T>
void SelectionSort(vector<T>list,int &compa, int &swaps){
    T aux=0;
    int comparaciones=compa;
    int intercambios=swaps;
    for (int i=0;i<list.size()-1;i++){
        aux=i;
        for (int j=i+1;j<list.size();j++){
            comparaciones++;
            if (list[j]<list[aux]){
                aux=j;
            }
        }
        if (aux!=i){
            intercambios++;
            swap(list,i,aux);
        }
    }
    print(list);
    cout<<"Comparaciones: "<<comparaciones<<" intercambios: "<<intercambios<< endl; 
}

template<class T>
void InsertionSort(vector<T>list,int &compa, int &swaps){
    int comparaciones=compa;
    int intercambios=swaps;
    for(int i=1;i<list.size();i++){
        int j=i-1;
        while (j>=0){
            if(list[j+1]<list[j]){
                intercambios++;
                swap(list,j+1,j);
            }else{
                j=-1;
            }
            j--;
        }
        if(j<0){
            comparaciones++;
        }
    }
    print(list);
    cout<<"Comparaciones: "<<comparaciones<<" intercambios: "<<intercambios<< endl;
}

template<class T>
void merge(vector<T> &list, int left, int mid, int right) {

    vector<T> listLeft;
    for (int i=left; i<=mid; i++) {
        listLeft.push_back(list[i]);
    }


    vector<T> listRight;
    for (int j=mid+1; j<=right; j++) {
        listRight.push_back(list[j]);
    }

    int auxIndex = left;

    int leftIndex = 0;
    int rightIndex = 0;
    while (leftIndex < listLeft.size() && rightIndex < listRight.size()) { 

        if (listLeft[leftIndex] < listRight[rightIndex]) {
    
            list[auxIndex] = listLeft[leftIndex];
    
            leftIndex++;
        } else {
       
            list[auxIndex] = listRight[rightIndex];
     
            rightIndex++;
        }

        auxIndex++;
    }

    while (leftIndex < listLeft.size()) {

        list[auxIndex] = listLeft[leftIndex];
        leftIndex++;
        auxIndex++;
    } 
    while (rightIndex < listRight.size()) {
        list[auxIndex] = listRight[rightIndex];
        rightIndex++;
        auxIndex++;
    }
}

template<class T>
void mergeSort(vector<T> &list, int left, int right) {
    if (left < right) { 
        int mid = left + (right - left) / 2;
        mergeSort(list, left, mid);
        mergeSort(list, mid+1, right);
        merge(list, left, mid, right);
    }
}

template<class T>
void quicksort(vector<T> &list, int left, int right) {
    int i = left;
    int j = right;
    int pivot = list[(left + right) / 2];
    while (i <= j) {
        while (list[i] < pivot) {
            i++;
        }
        while (list[j] > pivot) {
            j--;
        }
        if (i <= j) {
            swap(list, i, j);
            i++;
            j--;
        }
    }
    if (left < j) {
        quicksort(list, left, j);
    }
    if (i < right) {
        quicksort(list, i, right);
    }
}

template <class T>
void shellSort(vector<T> &list, int &compa, int &swaps) {
    int comparaciones=compa;
    int intercambios=swaps;
    int controlador=list.size()/2;
    while (controlador>0){
        for (int i=controlador; i<list.size(); i++){
            int j=i-controlador;
            while (j>=0){
                comparaciones++;
                if (list[j+controlador]<list[j]){
                    swap(list, j, j+controlador);
                    intercambios++;
                } else{
                    j=-1;
                }
                j-=controlador;
            }
        }
        controlador/=2;
    }
    print(list);
    cout<<"Comparaciones: "<<comparaciones<<" intercambios: "<<intercambios<< endl;
}


int secuencialsearchInt(vector<int>list, int data){
    int n=list.size()-1;
    for (int i=0;i<=n;i++){
        if (list[i]==data){
            cout<<"De forma secuencial el valor buscado se encuentra en la pocision: "<<i<<endl;
        }
    }
    return 0;
}

float secuencialsearchfloat(vector<float>list, float data){
    int n=list.size()-1;
    for (int i=0;i<=n;i++){
        if (list[i]==data){
            cout<<"De forma secuencial el valor buscado se encuentra en la pocision: "<<i<<endl;
        }
    }
    return 0;
}

char secuencialsearchar(vector<char>list, char data){
    int n=list.size()-1;
    for (int i=0;i<=n;i++){
        if (list[i]==data){
            cout<<"De forma secuencial el valor buscado se encuentra en la pocision: "<<i<<endl;
        }
    }
    return 0;
}

int binarysearchInt(vector<int>list, int data){

    int left=0;
    int right=list.size()-1;

    while(left<=right){

        int mid=left + (right-left)/2;

        if (data==list[mid]){

            cout<<"De manera binaria el valor buscado se encuentra en la pocision: "<<mid<<endl;
            return mid;

        }else{

            if(data<list[mid]){

                right=mid-1;

            }else{

                left=mid+1;
            }
        }
    }
    cout<<"El valor buscado no se encuentra en la lista"<<endl;
    return -1;
}

int binarysearchFloat(vector<float>list, float data){

    int left=0;
    int right=list.size()-1;

    while(left<=right){

        int mid=left + (right-left)/2;

        if (data==list[mid]){

            cout<<"De manera binaria el valor buscado se encuentra en la pocision: "<<mid<<endl;
            return mid;

        }else{

            if(data<list[mid]){

                right=mid-1;

            }else{

                left=mid+1;
            }
        }
    }
    cout<<"El valor buscado no se encuentra en la lista"<<endl;
    return -1;
}

char binarysearchChar(vector<char>list, char data){

    int left=0;
    int right=list.size()-1;

    while(left<=right){

        int mid=left + (right-left)/2;

        if (data==list[mid]){

            cout<<"De manera binaria el valor buscado se encuentra en la pocision: "<<mid<<endl;
            return mid;

        }else{

            if(data<list[mid]){

                right=mid-1;

            }else{

                left=mid+1;
            }
        }
    }
    cout<<"El valor buscado no se encuentra en la lista"<<endl;
    return -1;
}


int main(){


    chrono::high_resolution_clock::time_point begin;
    chrono::high_resolution_clock::time_point end;
    srand(time(0));


    vector<int> list1;
    vector<int> listaux;
    vector<char> list2;
    vector<char> listaux2;
    vector<float> list3;
    vector<float> listaux3; 
       
    int compa1=0;
    int swap1=0;
    int n;
    int cant;

    cout<<"Bienvenido al programa de ordenamiento y busqueda de listas"<<endl;

    int Tlist;
    cout << "Seleccione el tipo de lista aleatoria a crear:" << endl;
    cout << "1. Enteros" << endl;
    cout << "2. Caracteres" << endl;
    cout << "3. Flotantes" << endl;
    cin >> Tlist;

    if(Tlist==1){
        cout<<"Ingrese la cantidad de elementos aleatorios a generar: ";
        cin>>cant;
        createListInt(list1,cant);
        listaux=list1;
    }

    if(Tlist==2){
        cout<<"Ingrese la cantidad de elementos aleatorios a generar: ";
        cin>>cant;
        createListChar(list2,cant);
        listaux2=list2;
    }

    if(Tlist==3){
        cout<<"Ingrese la cantidad de elementos aleatorios a generar: ";
        cin>>cant;
        createListFloat(list3,cant);
        listaux3=list3;
    }

    cout<<"Deseas ordenar o buscar un elemento en la lista: "<<endl;
    cout<<"1. Ordenar"<<endl;
    cout<<"2. Buscar"<<endl;
    cout<<"0. Salir"<<endl;
    cin>>n;
    
    if(Tlist==1){

        while (n!=0){

            if (n==1){

                cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                cout<<"1. SwapSort"<<endl;
                cout<<"2. BubbleSort"<<endl;
                cout<<"3. SelectionSort"<<endl;
                cout<<"4. InsertionSort"<<endl;
                cout<<"5. MergeSort"<<endl;
                cout<<"6. QuickSort"<<endl;
                cout<<"7. ShellSort"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;

                while(n!=0){

                    if(n==1){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por swapsort"<<endl;
                        SwapSort(list1,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==2){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por bubblesort"<<endl;
                        BubbleSort(list1,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==3){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por selectionsort"<<endl;
                        SelectionSort(list1,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==4){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por insertionsort"<<endl;
                        InsertionSort(list1,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==5){
                        startTime(begin);   
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por mergesort"<<endl;
                        mergeSort(list1,0,list1.size()-1);
                        print(list1);
                        getTime(begin,end);
                    }

                    if(n==6){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por quicksort"<<endl;
                        quicksort(list1,0,list1.size()-1);
                        print(list1);
                        getTime(begin,end);
                    }
                    if (n==7){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux);
                        cout<<"Lista ordenada por shellsort"<<endl;
                        shellSort(list1,compa1,swap1);
                        getTime(begin,end);
                    }
                    

                    cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                    cout<<"1. SwapSort"<<endl;
                    cout<<"2. BubbleSort"<<endl;
                    cout<<"3. SelectionSort"<<endl;
                    cout<<"4. InsertionSort"<<endl;
                    cout<<"5. MergeSort"<<endl;
                    cout<<"6. QuickSort"<<endl;
                    cout<<"7. ShellSort"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            if (n==2){
                int data;
                cout<<"Ingrese el valor a buscar: ";
                cin>>data;
                cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                cout<<"1. Secuencial"<<endl;
                cout<<"2. Binaria"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;
                while(n!=0){
                    if(n==1){
                        startTime(begin);
                        secuencialsearchInt(list1,data);
                        getTime(begin,end);
                    }
                    if(n==2){
                        startTime(begin);
                        binarysearchInt(list1,data);
                        getTime(begin,end);
                    }
                    cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                    cout<<"1. Secuencial"<<endl;
                    cout<<"2. Binaria"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            
        }
    }

    if(Tlist==2){

        while (n!=0){

            if (n==1){

                cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                cout<<"1. SwapSort"<<endl;
                cout<<"2. BubbleSort"<<endl;
                cout<<"3. SelectionSort"<<endl;
                cout<<"4. InsertionSort"<<endl;
                cout<<"5. MergeSort"<<endl;
                cout<<"6. QuickSort"<<endl;
                cout<<"7. ShellSort"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;

                while(n!=0){

                    if(n==1){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por swapsort"<<endl;
                        SwapSort(list2,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==2){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por bubblesort"<<endl;
                        BubbleSort(list2,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==3){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por selectionsort"<<endl;
                        SelectionSort(list2,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==4){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por insertionsort"<<endl;
                        InsertionSort(list2,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==5){
                        startTime(begin);   
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por mergesort"<<endl;
                        mergeSort(list2,0,list2.size()-1);
                        print(list2);
                        getTime(begin,end);
                    }

                    if(n==6){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por quicksort"<<endl;
                        quicksort(list2,0,list2.size()-1);
                        print(list2);
                        getTime(begin,end);
                    }
                    if (n==7){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux2);
                        cout<<"Lista ordenada por shellsort"<<endl;
                        shellSort(list2,compa1,swap1);
                        getTime(begin,end);
                    }
                    

                    cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                    cout<<"1. SwapSort"<<endl;
                    cout<<"2. BubbleSort"<<endl;
                    cout<<"3. SelectionSort"<<endl;
                    cout<<"4. InsertionSort"<<endl;
                    cout<<"5. MergeSort"<<endl;
                    cout<<"6. QuickSort"<<endl;
                    cout<<"7. ShellSort"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            if (n==2){
                char data;
                cout<<"Ingrese el valor a buscar: ";
                cin>>data;
                cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                cout<<"1. Secuencial"<<endl;
                cout<<"2. Binaria"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;
                while(n!=0){
                    if(n==1){
                        startTime(begin);
                        secuencialsearchar(list2,data);
                        getTime(begin,end);
                    }
                    if(n==2){
                        startTime(begin);
                        binarysearchChar(list2,data);
                        getTime(begin,end);
                    }
                    cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                    cout<<"1. Secuencial"<<endl;
                    cout<<"2. Binaria"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            
        }
    }

    if(Tlist==3){

        while (n!=0){

            if (n==1){

                cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                cout<<"1. SwapSort"<<endl;
                cout<<"2. BubbleSort"<<endl;
                cout<<"3. SelectionSort"<<endl;
                cout<<"4. InsertionSort"<<endl;
                cout<<"5. MergeSort"<<endl;
                cout<<"6. QuickSort"<<endl;
                cout<<"7. ShellSort"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;

                while(n!=0){

                    if(n==1){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por swapsort"<<endl;
                        SwapSort(list3,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==2){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por bubblesort"<<endl;
                        BubbleSort(list3,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==3){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por selectionsort"<<endl;
                        SelectionSort(list3,compa1,swap1);
                        getTime(begin,end); 
                    }

                    if(n==4){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por insertionsort"<<endl;
                        InsertionSort(list3,compa1,swap1);
                        getTime(begin,end);
                    }

                    if(n==5){
                        startTime(begin);   
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por mergesort"<<endl;
                        mergeSort(list3,0,list3.size()-1);
                        print(list3);
                        getTime(begin,end);
                    }

                    if(n==6){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por quicksort"<<endl;
                        quicksort(list3,0,list2.size()-1);
                        print(list3);
                        getTime(begin,end);
                    }
                    if (n==7){
                        startTime(begin);
                        cout<<"Lista desordenada"<<endl;
                        print(listaux3);
                        cout<<"Lista ordenada por shellsort"<<endl;
                        shellSort(list3,compa1,swap1);
                        getTime(begin,end);
                    }
                    

                    cout<<"Con que tipo de algoritmo de ordenamiento desea ordenar la lista: "<<endl;
                    cout<<"1. SwapSort"<<endl;
                    cout<<"2. BubbleSort"<<endl;
                    cout<<"3. SelectionSort"<<endl;
                    cout<<"4. InsertionSort"<<endl;
                    cout<<"5. MergeSort"<<endl;
                    cout<<"6. QuickSort"<<endl;
                    cout<<"7. ShellSort"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            if (n==2){
                float data;
                cout<<"Ingrese el valor a buscar: ";
                cin>>data;
                cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                cout<<"1. Secuencial"<<endl;
                cout<<"2. Binaria"<<endl;
                cout<<"0. Salir"<<endl;
                cin>>n;
                while(n!=0){
                    if(n==1){
                        startTime(begin);
                        secuencialsearchfloat(list3,data);
                        getTime(begin,end);
                    }
                    if(n==2){
                        startTime(begin);
                        binarysearchFloat(list3,data);
                        getTime(begin,end);
                    }
                    cout<<"Con que tipo de algoritmo de busqueda desea buscar el valor: "<<endl;
                    cout<<"1. Secuencial"<<endl;
                    cout<<"2. Binaria"<<endl;
                    cout<<"0. Salir"<<endl;
                    cin>>n;
                }
            }
            
        }
    }
}

       
        
    
    
    
