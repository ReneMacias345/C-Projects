#ifndef Queue_h
#define Queue_h

#include "Node.h"

template <class T>
class Queue {
private:
    Node<T>* head;
    Node<T>* tail;
public:
    Queue();
    void push(T data); // Agrega un elemento al final de la fila
    void pop(); // Elemina el primer elemento de la fila y regresa su valor
    T front(); // Regresa el primer elemento de la fila
    bool isEmpty();
    void print(); 
};

template<class T>
Queue<T>::Queue() {
    head = nullptr;
    tail = nullptr;
}

template<class T>
void Queue<T>::push(T data) {
    if (isEmpty()) {
        head = new Node<T>(data);
        tail = head;
    }
    else {
        tail->next = new Node<T>(data);
        tail = tail->next;
    }
}

template<class T>
void Queue<T>::pop() {
    if (!isEmpty()) {
        Node<T>* aux = head;
        head = head->next;
        delete aux;
    }
    //regresa el valor del elemento eliminado
    
}

template<class T>
T Queue<T>::front() {
    if (!isEmpty()) {
        return head->data;
    }
    else {
        return T();
    }
}

template<class T>
bool Queue<T>::isEmpty() {
    return head == nullptr;
}

template<class T>
void Queue<T>::print() {
    Node<T>* aux = head;
    while (aux != nullptr) {
        cout << aux->data;
        if (aux->next != nullptr) {
            cout << " -> ";
        }
        aux = aux->next;
    }
    cout << endl;
}




#endif