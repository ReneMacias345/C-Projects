#include <iostream>
using namespace std;
#include "Queue.h"

int main() {

    Queue<string> queue;
    queue.push("Olla");
    queue.push("Estufa");
    queue.push("Jarra");
    queue.push("Plato");
    queue.print();
    queue.pop();
    queue.print();
    queue.push("Cuchara");
    queue.print();
    queue.front();
}
