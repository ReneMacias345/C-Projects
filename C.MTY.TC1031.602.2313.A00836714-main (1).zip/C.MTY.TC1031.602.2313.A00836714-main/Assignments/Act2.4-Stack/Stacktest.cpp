#include <iostream>
using namespace std;
#include "Stack.h"

int main() {
    Stack<int> s;
    s.push(1);
    s.push(2);
    s.push(3);
    s.print();
    s.pop();
    s.print();
    s.top();
    s.print();
};