#ifndef Stack_h
#define Stack_h

#include "Node.h"

template <class T>
class Stack {
private:
    Node<T>* head;
    Node<T>* tail;
public:
    Stack();
    void push(T data); // Agrega un elemento al final del stack
    void pop(); // Elemina el primer elemento del stack y regresa su valor
    T top(); // Regresa el ultimo elemento del stack
    bool isEmpty();
    void print(); 
    bool isEmpty();
    void print(); 
};


template<class T>
Stack<T>::Stack() {
    head = nullptr;
    tail = nullptr;
}

template<class T>
void Stack<T>::push(T data) {
    if (isEmpty()) {
        head = new Node<T>(data);
        tail = head;
    }
    else {
        tail->next = new Node<T>(data);
        tail = tail->next;
    }
}

template<class T>
void Stack<T>::pop() {
    if (!isEmpty()) {
        Node<T>* aux = head;
        head = head->next;
        delete aux;
    }
     
}

template<class T>
T Stack<T>::top() {
    if (!isEmpty()) {
        return head->data;
    }
    else {
        return T();
    }
}

template<class T>
bool Stack<T>::isEmpty() {
    return head == nullptr;
}

template<class T>
void Stack<T>::print() {
    Node<T>* aux = head;
    while (aux != nullptr) {
        cout << aux->data << " ";
        aux = aux->next;
    }
    cout << endl;
}









#endif