#ifndef DoublyLinkedList_h
#define DoublyLinkedList_h
#include "Node.h"

template<class T>

class DoublyLinkedList{
    
    private:
        Node<T>* head;
        Node<T>* tail;
        int size;

    public:
        DoublyLinkedList();
        int getSize();
        void addFirst(T data);
        void addLast(T data);
        void print();
        void insert(int index, T data);
        int findData(T data);
        void updateData(T data, T newData);
        T getData(int index);
        void updateAt(int index, T data);
        bool deleteData(T data);
        bool deleteAt(int index);
        T& operator[](int index);
        void operator=(DoublyLinkedList<T> list);
        void clear();
        void merge(Node<T>* left, Node<T>* mid, Node<T>* right);
        void mergeSort(Node<T>* left, Node<T>* right);
        void sort();
        void merge2(Node<T>* left, Node<T>* mid, Node<T>* right);
        void mergeSort2(Node<T>* left, Node<T>* right);
        void sort2();
        void duplicate();
        void removeDuplicates();

};

template<class T>
DoublyLinkedList<T>::DoublyLinkedList(){
    head = nullptr;
    tail = nullptr;
    size = 0;
}

template<class T>
int DoublyLinkedList<T>::getSize(){
    return size;
}

template<class T>
void DoublyLinkedList<T>::addFirst(T data){
    if (size == 0){
        head = new Node<T>(data);
        tail = head;
    } else {
        head->prev = new Node<T>(data, nullptr, head);
        head = head->prev;
    }
    size++;
}

template<class T>
void DoublyLinkedList<T>::addLast(T data){
    if (size == 0){
        addFirst(data);
    } else {
        tail->next = new Node<T>(data, tail, nullptr);
        tail = tail->next;
        size++;
    }
}

template<class T>
void DoublyLinkedList<T>::print(){
    Node<T>* aux = head;
    while(aux != nullptr){
        cout << aux->data;
        if (aux->next != nullptr){
            cout << " <-> ";
        }
        aux = aux->next;
    }
    cout << endl;
}

template<class T>
void DoublyLinkedList<T>::insert(int index, T data) {
    if (index >= 0 && index < size) {
        if (index == size - 1) {
            addLast(data);
        } else {
            Node<T>* aux = head;
            int auxIndex = 0;
            while (auxIndex < index) {
                aux = aux->next;
                auxIndex++;
            }
            Node<T>* newNode = new Node<T>(data, aux, aux->next);
            aux->next->prev = newNode;
            aux->next = newNode;
            size++;
        }
    } else {
        throw out_of_range("El indice esta fuera de rango");
    }
}

template<class T>
int DoublyLinkedList<T>::findData(T data){
    Node<T>* aux = head;
    int auxIndex = 0;
    while(aux != nullptr){
        if (aux->data == data){
            return auxIndex;
        }
        aux = aux->next;
        auxIndex++;
    }
    return -1;
}

template<class T>
void DoublyLinkedList<T>::updateData(T data, T newData){
    Node<T>* aux = head;
    while(aux != nullptr){
        if (aux->data == data){
            aux->data = newData;
            return;
        }
        aux = aux->next;
    }
    throw out_of_range("No se encontró en la lista");
}

template<class T>
T DoublyLinkedList<T>::getData(int index){
    if (index >= 0 && index < size){
        Node<T>* aux = head;
        for (int i = 0; i < index; i++){
            aux = aux->next;
        }
        return aux->data;
    } else {
        throw out_of_range("indexición inválida");
    }
}

template<class T>
void DoublyLinkedList<T>::updateAt(int index, T data){
    if (index >= 0 && index < size){
        Node<T>* aux = head;
        for (int i = 0; i < index; i++){
            aux = aux->next;
        }
        aux->data = data;
    } else {
        throw out_of_range("indexición inválida");
    }
}

template<class T>
bool DoublyLinkedList<T>::deleteData(T data){
    if (size == 0){
        return false;
    } else {
        Node<T>* aux = head;
        while (aux != nullptr){
            if (aux->data == data){
                if (aux == head){
                    head = aux->next;
                    if (head != nullptr) {
                        head->prev = nullptr;
                    }
                } else if (aux == tail) {
                    tail = aux->prev;
                    tail->next = nullptr;
                } else {
                    aux->prev->next = aux->next;
                    aux->next->prev = aux->prev;
                }
                delete aux;
                size--;
                return true;
            }
            aux = aux->next;
        }
        return false;
    }
}

template<class T>
bool DoublyLinkedList<T>::deleteAt(int index){
    if (index >= 0 && index < size){
        Node<T>* aux = head;
        for (int i = 0; i < index; i++){
            aux = aux->next;
        }
        if (aux == head){
            head = aux->next;
            head->prev = nullptr;
        } else if (aux == tail) {
            tail = aux->prev;
            tail->next = nullptr;
        } else {
            aux->prev->next = aux->next;
            aux->next->prev = aux->prev;
        }
        delete aux;
        size--;
        return true;
    } else {
        return false;
    }
}

template <class T>
T& DoublyLinkedList<T>::operator[](int index) {
    if (index >= 0 && index < size) {
        Node<T>* aux = head;
        int auxIndex = 0;
        while (auxIndex < index) {
            aux = aux->next;
            auxIndex++;
        }
        return aux->data;
    } else {
        throw out_of_range("Índice inválido");
    }
}

template <class T>
void DoublyLinkedList<T>::operator=(DoublyLinkedList<T> list) {
    clear();
    Node<T>* aux = list.head;
    while (aux != nullptr) {
        addLast(aux->data);
        aux = aux->next;
    }
}

template<class T>
void DoublyLinkedList<T>::clear(){
    Node<T>* aux = head;
    while (aux != nullptr) {
        Node<T>* temp = aux;
        aux = aux->next;
        delete temp;
    }
    head = nullptr;
    tail = nullptr;
    size = 0;
}

template<class T>
void DoublyLinkedList<T>::merge(Node<T>* left, Node<T>* mid, Node<T>* right) {
    DoublyLinkedList<T> leftList;
    DoublyLinkedList<T> rightList;

    Node<T>* current = left;
    while (current != mid->next) {
        leftList.addLast(current->data);
        current = current->next;
    }
    current = mid->next;
    while (current != right->next) {
        rightList.addLast(current->data);
        current = current->next;
    }

    current = left;
    Node<T>* leftCurrent = leftList.head;
    Node<T>* rightCurrent = rightList.head;

    while (leftCurrent && rightCurrent) {
        if (leftCurrent->data < rightCurrent->data) {
            current->data = leftCurrent->data;
            leftCurrent = leftCurrent->next;
        } else {
            current->data = rightCurrent->data;
            rightCurrent = rightCurrent->next;
        }
        current = current->next;
    }
    while (leftCurrent) {
        current->data = leftCurrent->data;
        leftCurrent = leftCurrent->next;
        current = current->next;
    }
    while (rightCurrent) {
        current->data = rightCurrent->data;
        rightCurrent = rightCurrent->next;
        current = current->next;
    }
}

template<class T>
void DoublyLinkedList<T>::mergeSort(Node<T>* left, Node<T>* right) {
    if (left != nullptr && right != nullptr && left != right && left->prev != right) {
        Node<T>* mid = left;
        Node<T>* fast = left;
        while (fast != right && fast->next != right) {
            mid = mid->next;
            fast = fast->next->next;
        }
        mergeSort(left, mid);
        mergeSort(mid->next, right);
        merge(left, mid, right);
    }
}

template<class T>
void DoublyLinkedList<T>::sort() {
    if (size <= 1) {
        return;
    }
    mergeSort(head, tail);
}

template<class T>
void DoublyLinkedList<T>::merge2(Node<T>* left, Node<T>* mid, Node<T>* right) {
    DoublyLinkedList<T> leftList;
    DoublyLinkedList<T> rightList;

    Node<T>* current = left;
    while (current != mid->next) {
        leftList.addLast(current->data);
        current = current->next;
    }
    current = mid->next;
    while (current != right->next) {
        rightList.addLast(current->data);
        current = current->next;
    }

    current = left;
    Node<T>* leftCurrent = leftList.head;
    Node<T>* rightCurrent = rightList.head;

    while (leftCurrent && rightCurrent) {
        if (leftCurrent->data > rightCurrent->data) {  // Cambio a operador >
            current->data = leftCurrent->data;
            leftCurrent = leftCurrent->next;
        } else {
            current->data = rightCurrent->data;
            rightCurrent = rightCurrent->next;
        }
        current = current->next;
    }
    while (leftCurrent) {
        current->data = leftCurrent->data;
        leftCurrent = leftCurrent->next;
        current = current->next;
    }
    while (rightCurrent) {
        current->data = rightCurrent->data;
        rightCurrent = rightCurrent->next;
        current = current->next;
    }
}

template<class T>
void DoublyLinkedList<T>::mergeSort2(Node<T>* left, Node<T>* right) {
    if (left != nullptr && right != nullptr && left != right && left->prev != right) {
        Node<T>* mid = left;
        Node<T>* fast = left;
        while (fast != right && fast->next != right) {
            mid = mid->next;
            fast = fast->next->next;
        }
        mergeSort2(left, mid);
        mergeSort2(mid->next, right);
        merge2(left, mid, right);
    }
}

template<class T>
void DoublyLinkedList<T>::sort2() {
    if (size <= 1) {
        return;
    }
    mergeSort2(head, tail);
}


template<class T>
void DoublyLinkedList<T>::duplicate() {
    Node<T>* current = head;
    while (current != nullptr) {
        Node<T>* newNode = new Node<T>(current->data);
        Node<T>* nextNode = current->next;
        current->next = newNode;
        newNode->prev = current;
        newNode->next = nextNode;
        if (nextNode != nullptr) {
            nextNode->prev = newNode;
        }
        current = nextNode;
        size++;
    }
}

template<class T>
void DoublyLinkedList<T>::removeDuplicates() {    
    sort();

    Node<T>* current = head;
    while (current->next != nullptr) {
        if (current->data == current->next->data) {
            Node<T>* duplicate = current->next;
            current->next = duplicate->next;
            if (duplicate->next != nullptr) {
                duplicate->next->prev = current;
            }
            delete duplicate;
            size--;
        } else {
            current = current->next;
        }
    }
}


#endif