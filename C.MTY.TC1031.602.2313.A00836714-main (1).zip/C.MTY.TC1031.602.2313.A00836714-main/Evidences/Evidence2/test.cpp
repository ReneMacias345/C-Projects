#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "Log.h"
#include "DoublyLinkedList.h"
#include <map> 

using namespace std;

int main() {
    DoublyLinkedList<Log> logList1;
    DoublyLinkedList<string> logList2;
    DoublyLinkedList<string> logList3;

    string year, month, day, time, ip, message;
    string line, word;
    ifstream fileIn("log602-2.txt");

    cout << "Menú:" << endl;
    cout << "1. Ordenar los datos por fecha y hora." << endl;
    cout << "2. Ordenar los datos por IP, fecha y hora." << endl;
    cout << "3. Buscar registros por rango de IP." << endl;
    cout << "4. Cantidad de ips en el archivo por cada año y mes." << endl;
    cout << "5. Salir." << endl;
    cout << "Selecciona una opción: ";

    int opcion;
    cin >> opcion;

    if (opcion == 1) {

        while (getline(fileIn, line)) {
            stringstream vAux(line);
            vAux >> month >> day >> year >> time >> ip >> message;
            while (vAux >> word) {
                message = message + " " + word;
            }

            Log log_a(year, month, day, time, ip, message);
            logList1.addFirst(log_a);
        }

        logList1.sort();
        ofstream outFile("output602-1.out");
        for (int j = 0; j < logList1.getSize(); j++) {
            outFile << logList1[j] << endl;
        }
        outFile.close();
        cout << "Datos ordenados por fecha y hora y guardados en output602-1.out" << endl;
    

        }else if (opcion == 2) {
        while (getline(fileIn, line)) {
            stringstream vAux(line);
            vAux >> month >> day >> year >> time >> ip >> message;
            while (vAux >> word) {
                message = message + " " + word;
            }

            Log log_a(year, month, day, time, ip, message);
            log_a.replaceIpDotsWithZero();
            logList2.addFirst("Log: " + log_a.getIpKey() + " " + log_a.getMonth()+ " " + log_a.getDay() + " " + log_a.getYear() +" "+log_a.getTime()+  " " + log_a.getMessage());
        }

        // Ordena la lista utilizando el comparador personalizado
        logList2.sort();

        ofstream outFile("output602-2.out");
        for (int j = 0; j < logList2.getSize(); j++) {
            outFile << logList2[j] << endl;
        }
        outFile.close();
        cout << "Datos ordenados por IP, fecha y hora y guardados en output602-2.out" << endl;
    }
    else if (opcion == 3) {
        string startIp, endIp;
        int ascodesc;
        cout << "Introduce la IP de inicio del rango: ";
        cin >> startIp;
        cout << "Introduce la IP de fin del rango: ";
        cin >> endIp;
        cout << "¿Desea ordenar los datos de forma ascendente o descendente?" << endl;
        cout << "1. Ascendente" << endl;
        cout << "2. Descendente" << endl;
        cin >> ascodesc;

        while (getline(fileIn, line)) {
            stringstream vAux(line);
            vAux >> month >> day >> year >> time >> ip >> message;
            while (vAux >> word) {
                message = message + " " + word;
            }

            Log log_a(year, month, day, time, ip, message);
            if (log_a.getIpKey() >= startIp && log_a.getIpKey() <= endIp) {
                logList3.addFirst("Log: " + log_a.getIpKey() + " " + log_a.getMonth()+ " " + log_a.getDay() + " " + log_a.getYear() +" "+log_a.getTime()+  " " + log_a.getMessage());
            }
        }

        if (ascodesc == 1) {
            logList3.sort();
            ofstream outFile("iprange602-a.out");
            for (int j = 0; j < logList3.getSize(); j++) {
            outFile << logList3[j] << endl;
            }
            outFile.close();

        } else if (ascodesc == 2) {
            logList3.sort2();
            ofstream outFile("iprange602-d.out");
            for (int j = 0; j < logList3.getSize(); j++) {
            outFile << logList3[j] << endl;
            }
            outFile.close();
        }
        cout << "Datos dentro del rango de IPs guardados en ";
        if (ascodesc == 1) {
            cout << "iprange602-a.out" << endl;
        } else if (ascodesc == 2) {
            cout << "iprange602-d.out" << endl;
        }
    }
    else if (opcion == 4) {
        map<string, int> ipCounts;

        while (getline(fileIn, line)) {
            stringstream vAux(line);
            vAux >> month >> day >> year >> time >> ip >> message;
            while (vAux >> word) {
                message = message + " " + word;
            }

            Log log_a(year, month, day, time, ip, message);

            string yearMonthKey = year + "-" + month;

            ipCounts[yearMonthKey]++;
        }

        for (const auto& pair : ipCounts) {
            cout << "Fecha: " << pair.first << ", Total de Ips: " << pair.second << endl;
        }

    }


    return 0;
}