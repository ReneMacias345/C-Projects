//Rene Miguel Macias Olivar
//A00836714
//ITC
//Evidencia 1 - Actividad Integral de Conceptos Básicos y Algoritmos Fundamentales (Evidencia Competencia)
// Programación de estructuras de datos y algoritmos fundamentales (Gpo 602)

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include "Log.h"
using namespace std;

//Funcion para imprimir un vector

template<class T>
void print(const vector<T>& list) {
    for (const auto& item : list) {
        cout << item << endl;
    }
}

//Funcion para ordenar un vector

template<class T>
void merge(vector<T>& list, int left, int mid, int right) {
    vector<T> listLeft(list.begin() + left, list.begin() + mid + 1);
    vector<T> listRight(list.begin() + mid + 1, list.begin() + right + 1);

    int leftIndex = 0;
    int rightIndex = 0;
    int auxIndex = left;

    while (leftIndex < listLeft.size() && rightIndex < listRight.size()) {
        if (listLeft[leftIndex] < listRight[rightIndex]) {
            list[auxIndex++] = listLeft[leftIndex++];
        } else {
            list[auxIndex++] = listRight[rightIndex++];
        }
    }

    while (leftIndex < listLeft.size()) {
        list[auxIndex++] = listLeft[leftIndex++];
    }

    while (rightIndex < listRight.size()) {
        list[auxIndex++] = listRight[rightIndex++];
    }
}

//

template<class T>
void mergeSort(vector<T>& list, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(list, left, mid);
        mergeSort(list, mid + 1, right);
        merge(list, left, mid, right);
    }
}

//Funcion para buscar un elemento en un vector

template<class T>
int binarySearch(const vector<T>& list, int left, int right, const T& target) {
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (list[mid] == target) {
            return mid;
        }
        if (list[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1; // Si no se encuentra el elemento
}

int main() {
    // Lee el archivo "log602.txt" y lo guarda en un vector de objetos Log
    vector<Log> logAux;

    string year, month, day, time, ip, message;
    string line, word;
    ifstream fileIn("log602.txt");

    while (getline(fileIn, line)) {
        stringstream vAux(line);
        vAux >> month >> day >> year >> time >> ip >> message;
        while (vAux >> word) {
            message = message + " " + word;
        }

        Log log_a(year, month, day, time, ip, message);
        logAux.push_back(log_a);
    }

    // Ordena el vector de objetos Log y lo escribe en el archivo "output602.txt"

    int left = 0;
    int right = logAux.size() - 1;
    mergeSort(logAux, left, right);

    ofstream List("output602.txt");
    for (int j = 0; j <= right; j++) {
        List << logAux[j] << endl;
    }

    //print(logAux);
    List.close();

    // Búsqueda binaria en el rango de fechas y horas ingresado por el usuario.
    vector<Log> RangeAux;
    string start_date, end_date, start_time, end_time;
    cout << "Ingrese la fecha y hora de inicio (YYYY MM DD HH:MM): ";
    cin >> start_date >> month >> day >> start_time;
    cout << "Ingrese la fecha y hora de fin (YYYY MM DD HH:MM): ";
    cin >> end_date >> month >> day >> end_time;

    // Crea dos objetos Log con las fechas y horas ingresadas por el usuario

    Log start_log(start_date, month, day, start_time, "", "");
    Log end_log(end_date, month, day, end_time, "", "");

    // Busca los índices de los objetos Log en el vector logAux

    int start_index = binarySearch(logAux, 0, right, start_log);
    int end_index = binarySearch(logAux, 0, right, end_log);

    // Si no se encuentran los objetos Log, imprime un mensaje

    if (start_index == -1 || end_index == -1) {
        cout << "No se encontraron registros en el rango especificado." << endl;
    } else {
        // Guarda los registros en RangeAux y escribe en el archivo "range602.txt"
        for (int i = start_index; i <= end_index; i++) {
            RangeAux.push_back(logAux[i]);
        }

        ofstream RangeFile("range602.txt");
        for (int i=0; i <= RangeAux.size(); i++) {
            RangeFile << RangeAux[i] << endl;
        }
        RangeFile.close();
    }

    return 0;
}

