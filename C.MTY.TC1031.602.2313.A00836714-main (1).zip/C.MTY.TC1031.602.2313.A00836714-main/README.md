# Estructura de Datos y Algoritmos Fundamentales
### TC1031 - Gpo 602
### Nombre: 
## Escribe tu nombre
### Matrícula: 
## Escribe tu matrícula
### Carrera: 
## Escribe las iniciales de tu carrera
